﻿package ar.edu.udeci.pv;

import org.apache.commons.cli.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class App {
    private static final Logger logger = LogManager.getLogger(App.class);

    public static void main(String[] args) {
        // Ejemplo de uso de log4j
        logger.info("La aplicación Actividad2 ha comenzado.");

        // Ejemplo de uso de commons-cli
        Options options = new Options();

        Option input = new Option("i", "input", true, "archivo de entrada");
        input.setRequired(false);
        options.addOption(input);

        Option output = new Option("o", "output", true, "archivo de salida");
        output.setRequired(false);
        options.addOption(output);

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd;

        try {
            cmd = parser.parse(options, args);
        } catch (ParseException e) {
            System.out.println(e.getMessage());
            formatter.printHelp("Actividad2", options);
            System.exit(1);
            return; // Para evitar el warning de "cmd might not have been initialized"
        }

        String inputFile = cmd.getOptionValue("input");
        String outputFile = cmd.getOptionValue("output");

        logger.info("Valor del parámetro -input: " + inputFile);
        logger.info("Valor del parámetro -output: " + outputFile);

        System.out.println("¡Hola desde Actividad2 con commons-cli y log4j!");
        logger.info("La aplicación Actividad2 ha finalizado.");
    }
}
